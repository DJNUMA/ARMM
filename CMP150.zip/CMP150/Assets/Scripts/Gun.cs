using UnityEngine;

public class Gun : MonoBehaviour 
{
    public float bulletSpeed, fireRate;
    public Bullet Ammo;
    public Control shoot;


	void Start () 
    {
	
	}
	

	void Update () 
    {
        if (shoot.Activated)
        {
            Fire();
            Debug.Log("BANG");
        }
	}

    void Fire()
    {
        Bullet bullet = ((Bullet)Instantiate(Ammo, transform.position,transform.rotation));
        bullet.Speed = bulletSpeed;
    }
}

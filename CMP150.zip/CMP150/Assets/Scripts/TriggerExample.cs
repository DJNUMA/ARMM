using UnityEngine;
using System.Collections;

public class TriggerExample : MonoBehaviour {
	
	public static int Count = 0;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

      void OnTriggerEnter(Collider other)
    {
       Destroy(gameObject);
        Count++;
    }


    void OnCollisionEnter(Collision other)
    {
        Destroy(gameObject);
        Count++;
    }
}

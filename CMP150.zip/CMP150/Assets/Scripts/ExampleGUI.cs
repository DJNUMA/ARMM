using UnityEngine;

public class ExampleGUI : TriggerExample
{
    
    void OnGUI()
    {
        GUILayout.BeginArea(new Rect (10, 10, 100, 100));
        GUILayout.TextField("Score: " + Count.ToString());
        GUILayout.EndArea();
    }
    
    
}


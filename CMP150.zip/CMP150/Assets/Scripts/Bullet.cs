using UnityEngine;
using System.Collections;

public class Bullet : Enemy
{

	// Use this for initialization
	void Start () 
    {
	
	}
	
	// Update is called once per frame
	void Update () 
    {
        
        transform.Translate(transform.InverseTransformDirection(transform.forward) * Speed * Time.deltaTime);
	}

    public float Speed;

    void OnTriggerEnter(Collider Enemy)
    {
        Destroy(Enemy.gameObject);
		//Destroy(Bullet.gameObject);
    }
}

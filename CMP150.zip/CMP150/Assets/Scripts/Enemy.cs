using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Enemy : MonoBehaviour {
	
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}

      void OnTriggerEnter(Collider Bullet)
    {
       Destroy(gameObject);
       SceneManager.LoadScene("test");
    }


    void OnCollisionEnter(Collision Bullet)
    {
        Destroy(gameObject);
    }
}

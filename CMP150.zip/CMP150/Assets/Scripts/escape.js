﻿#pragma strict
import UnityEngine.UI;
var IsPaused : boolean = false;
var canvas : CanvasGroup;
function Start () {
	
}

function Update () {
    if (Input.GetKeyDown(KeyCode.Escape))
    {
        IsPaused = !IsPaused;
    }
    if(IsPaused){
        canvas.alpha = 1f;
    } else {
        canvas.alpha = 0f;
    }
}

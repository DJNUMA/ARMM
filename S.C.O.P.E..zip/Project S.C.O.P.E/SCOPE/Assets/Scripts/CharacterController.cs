﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**Known Bugs! 
 * 1: Animator does not respond correctly
 * 2: Character only changes direction once.
 */
public class CharacterController : MonoBehaviour {
    public float maxSpeed = 10;
    public float maxJump = 10;
    private bool facingRight = true;
    private Rigidbody2D rb;
    Animator anim;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody2D> ();
        anim.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
        float move = Input.GetAxis("Horizontal");
        float jump = Input.GetAxis("Vertical");
        //Sets the animator to change to the walk animation.
        // anim.SetFloat("Speed", Mathf.Abs(move));
        //Add in the Jump controls.
    
        rb.velocity = new Vector2(move*maxSpeed, rb.velocity.y);

        if (move < 0 && !facingRight)
            flip();
        if (move < 0 && facingRight != true)
            flip();
    }
    //Should flip the character picture on the X axis.
    /**TODO: Transition only occurs once, fix that bug.
     */
    void flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicsObject : MonoBehaviour {
    //Note, for this to work, we have to have a kinematic Rigidbody2d
    //this is simply the base class for all physics interactions in the game, player control is done separately
    //Class has been made by following an official Unity tutorial guide on the official Unity site.
    public float minGroundNormalY = .65f;
    public float gravityModifier = 1f;

    protected bool isGrounded;
    protected Vector2 groundNormal;
    protected Vector2 velocity;
    protected Vector2 targetVelocity;
    protected Rigidbody2D rb2d;
    protected ContactFilter2D contactFilter;
    protected RaycastHit2D[] hitBuffer = new RaycastHit2D[16];
    protected List<RaycastHit2D> hitBufferList = new List<RaycastHit2D>(16);

    protected const float shellRadius = 0.01f;
    protected const float minMoveDistance = 0.001f;

    void OnEnable()
    {
        rb2d = GetComponent<Rigidbody2D> ();
    }
	// Use this for initialization
	void Start () {
        contactFilter.useTriggers = false;
        //uses the layer matrix in Physics2d to collide with things
        contactFilter.SetLayerMask(Physics2D.GetLayerCollisionMask(gameObject.layer));
        contactFilter.useLayerMask = true;
    }
	
	// Update is called once per frame
	void Update () {
        targetVelocity = Vector2.zero;
        ComputeVelocity();
	}

    protected virtual void ComputeVelocity() { }
    //Movement is tested separately in this update function., X first, then Y.
    //This is done because this beter handles slopes.. its how it was done in the 16 bit era
    //so really it's good enough to be what I consider the standard for doing it.
    void FixedUpdate()
    {
        velocity += gravityModifier * Physics2D.gravity * Time.deltaTime;
        velocity.x = targetVelocity.x;

        isGrounded = false;

        //does what it says, calculates the angle based on the ground normal so we can move smoothly.
        Vector2 moveAlongGround = new Vector2(groundNormal.y, -groundNormal.x);
        //apply velocity to object and move it by detemrining where the object is based on gravity.
        Vector2 deltaPosition = velocity * Time.deltaTime;
        //Declare movement as a vector2.
        Vector2 move = moveAlongGround * deltaPosition.x;
        //do the horizontal movement.
        Movement(move, false);
        
        //Do the vertical movement.
        move = Vector2.up * deltaPosition.y;
        //call movement
        Movement(move, true);
    }

    void Movement(Vector2 move, bool yMovement)
    {
        float distance = move.magnitude;
        if (distance > minMoveDistance) {
            int count = rb2d.Cast(move, contactFilter, hitBuffer, distance + shellRadius);
            //copy only the stuff that hits something (Active contacts)
            hitBufferList.Clear();
            //get a list of objects that will overlap our physics collider.
            for (int i = 0; i < count; i++) {
                hitBufferList.Add(hitBuffer[i]);
            }

            //determine the angle of the things we're colliding with.
            //loop over hitbufferlist to compare the normal to a ground normal value
            for (int i = 0; i < hitBufferList.Count; i++) {
                Vector2 currentNormal = hitBufferList[i].normal;
                //will make sure that player is grounded(visibly) only if standing on a slope that is "normal"
                if (currentNormal.y > minGroundNormalY)
                {
                    isGrounded = true;
                    if (yMovement) {
                        groundNormal = currentNormal;
                        currentNormal.x = 0;
                    }
                }
                //getting the difference between the velocity and the current normal.
                //situation trying to avoid is if there's a ceiling, we want the player to continue.
                float projection = Vector2.Dot(velocity, currentNormal);
                if(projection < 0)
                {
                    velocity = velocity - projection * currentNormal;
                }
                float modifiedDistance = hitBuffer[i].distance - shellRadius;
                //disnace = modified distance if distance is less than modified distance, otherwise use distance.
                distance = modifiedDistance < distance ? modifiedDistance : distance;
            }
        }
        rb2d.position = rb2d.position + move.normalized *distance;
    }
}

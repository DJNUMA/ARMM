﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPlatformerController : PhysicsObject {

    public float jumpTakeoffSpeed = 7;
    public float maxSpeed = 7;

    private SpriteRenderer spriteRenderer;
    private Animator animator;

	// Use this for initialization
	void Awake () {
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator.GetComponent<Animator>();
	}
	
    protected override void ComputeVelocity()
    {
        Vector2 move = Vector2.zero;

        move.x = Input.GetAxis("Horizontal");

        //if jump button is pressed.
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            velocity.y = jumpTakeoffSpeed;
        }
        //If jump is released reduce velocity by half.
        else if (Input.GetButtonUp("Jump"))
        {
            if (velocity.y > 0)
                velocity.y = velocity.y * .5f;
        }

        /**Flippity doo da, flippity day
         * bool called flipSprite to determine sprite direction
         * flip it if move.x > 0.01, otherwise if its less we'll do the same thing
         */
        bool flipSprite = (spriteRenderer.flipX ? (move.x > 0.01f) : (move.x < 0.01f));
        if (flipSprite)
        {
            spriteRenderer.flipX = !spriteRenderer.flipX;
        }
        //Make sure that the jump animation works as intended.
        //animator.SetBool("isGrounded", isGrounded);
        //animator.SetFloat("velocityX", Mathf.Abs(velocity.x) / maxSpeed);
        //multiply the movement vector that we calculated based on the speed of the player.
        targetVelocity = move * maxSpeed;
    }
}

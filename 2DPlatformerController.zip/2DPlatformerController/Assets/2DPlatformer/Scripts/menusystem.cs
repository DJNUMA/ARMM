﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class menusystem : MonoBehaviour
{

    public void quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
                        Application.Quit();
#endif
    }

    public void play_game()
    {
        SceneManager.LoadScene(1);
    }

    public void view_achievements()
    {
        SceneManager.LoadScene(2);
    }

    public void game_options()
    {
        SceneManager.LoadScene(3);
    }

    public void show_mainmenu()
    {
        SceneManager.LoadScene(0);
    }

}
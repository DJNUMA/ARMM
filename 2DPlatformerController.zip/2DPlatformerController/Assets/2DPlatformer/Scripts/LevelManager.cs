﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour {

    public GameObject respawnZone;
    public int lives = 3;
    private PlayerPlatformerController player;
    private Text livesText;
    public int score = 25000;
    private Text scoreText;

    void Start () {
        player = FindObjectOfType<PlayerPlatformerController>();
        player.transform.position = respawnZone.transform.position;
        livesText = GameObject.Find("livesCounter").GetComponent<Text>();
        scoreText = GameObject.Find("scoreCounter").GetComponent<Text>();
        scoreText.text = "Score: " + score;
    }

	void Update () {
        if(score > 0)
            score--;
        scoreText.text = "Score: " + score;
        if (score <= 0)
            SceneManager.LoadScene(1);
	}

    public void RespawnPlayer()
    {
        Debug.Log("Player Respawn ");
        player.transform.position = respawnZone.transform.position;
    }

    public void loseLife()
    {
        switch (lives)
        {
            case 1:
                SceneManager.LoadScene(4);
                break;
            default:
                lives--;
                livesText.text = "Lives: " + lives;
                score -= 7500;
                RespawnPlayer();
                break;
        }
    }

    public void collectCoin()
    {
        score += 2500;
    }

}

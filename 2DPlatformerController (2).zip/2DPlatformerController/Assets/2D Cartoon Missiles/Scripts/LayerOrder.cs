﻿using UnityEngine;

public class LayerOrder : MonoBehaviour
{
    public int Order = 0;
    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.sortingOrder = Order;
    }
}